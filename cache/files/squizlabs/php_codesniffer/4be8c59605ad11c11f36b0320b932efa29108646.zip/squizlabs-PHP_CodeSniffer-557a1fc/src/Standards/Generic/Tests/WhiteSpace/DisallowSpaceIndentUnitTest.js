var x = {
	abc: 1,
    zyz: 2,
	abc: 5,
	mno: {
	  abc: 4
	},
	abc: 5
}
