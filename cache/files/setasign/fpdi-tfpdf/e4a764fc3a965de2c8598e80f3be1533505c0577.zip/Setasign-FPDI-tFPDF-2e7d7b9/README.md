# FPDI-tFPDF
A kind of metadata package for Composer with fixed dependencies for the latest versions of FPDI and tFPDF

## Installation with [Composer](https://packagist.org/packages/setasign/fpdi-tfpdf)

```bash
$ composer require setasign/fpdi-tfpdf:2.2
```

or you can include the following in your composer.json file:

```json
{
    "require": {
        "setasign/fpdi-tfpdf": "^2.2"
    }
}
```
