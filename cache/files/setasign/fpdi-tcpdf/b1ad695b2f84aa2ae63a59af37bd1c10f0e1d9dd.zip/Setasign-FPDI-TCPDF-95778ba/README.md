# FPDI-TCPDF
A kind of metadata package for Composer with fixed dependencies for the latest versions of FPDI and TCPDF.

## Installation with [Composer](https://packagist.org/packages/setasign/fpdi-tcpdf)

```bash
$ composer require setasign/fpdi-tcpdf:2.2
```

or you can include the following in your composer.json file:

```json
{
    "require": {
        "setasign/fpdi-tcpdf": "^2.2"
    }
}
```
