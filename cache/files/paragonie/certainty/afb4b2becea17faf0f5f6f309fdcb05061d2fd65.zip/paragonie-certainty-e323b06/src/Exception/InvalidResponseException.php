<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class InvalidResponseException
 * @package ParagonIE\Certainty\Exception
 */
class InvalidResponseException extends CertaintyException
{

}
