<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class EncodingException
 * @package ParagonIE\Certainty\Exception
 */
class EncodingException extends CertaintyException
{

}
