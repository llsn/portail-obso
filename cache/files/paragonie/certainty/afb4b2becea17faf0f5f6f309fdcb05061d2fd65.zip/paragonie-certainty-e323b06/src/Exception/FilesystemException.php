<?php
namespace ParagonIE\Certainty\Exception;

/**
 * Class FilesystemException
 * @package ParagonIE\Certainty\Exception
 */
class FilesystemException extends CertaintyException
{

}
