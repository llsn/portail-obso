<?php
namespace Zend\Permissions\Acl\Assertion\Exception;

use Zend\Permissions\Acl\Exception\ExceptionInterface;

class InvalidAssertionException extends \InvalidArgumentException implements ExceptionInterface
{
}
