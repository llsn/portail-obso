# zend-json-server

[![Build Status](https://secure.travis-ci.org/zendframework/zend-json-server.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-json-server)
[![Coverage Status](https://coveralls.io/repos/github/zendframework/zend-json-server/badge.svg?branch=master)](https://coveralls.io/github/zendframework/zend-json-server?branch=master)

Provides a JSON-RPC server implementation.

- File issues at https://github.com/zendframework/zend-json-server/issues
- Documentation is at https://docs.zendframework.com/zend-json-server/
