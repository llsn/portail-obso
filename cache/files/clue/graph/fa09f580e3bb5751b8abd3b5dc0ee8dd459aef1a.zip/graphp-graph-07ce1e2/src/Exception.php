<?php

namespace Fhaculty\Graph;

interface Exception
{
}
