<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class LogicException extends \LogicException implements Graph\Exception
{
}
