<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class UnexpectedValueException extends \UnexpectedValueException implements Graph\Exception
{
}
