<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class InvalidArgumentException extends \InvalidArgumentException implements Graph\Exception
{
}
