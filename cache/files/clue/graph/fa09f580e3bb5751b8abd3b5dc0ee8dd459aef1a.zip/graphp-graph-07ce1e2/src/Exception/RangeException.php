<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class RangeException extends \RangeException implements Graph\Exception
{
}
