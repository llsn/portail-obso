<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class OutOfBoundsException extends \OutOfBoundsException implements Graph\Exception
{
}
