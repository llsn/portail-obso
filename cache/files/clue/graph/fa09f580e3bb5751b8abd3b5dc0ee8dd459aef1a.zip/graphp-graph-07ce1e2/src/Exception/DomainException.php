<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class DomainException extends \DomainException implements Graph\Exception
{
}
