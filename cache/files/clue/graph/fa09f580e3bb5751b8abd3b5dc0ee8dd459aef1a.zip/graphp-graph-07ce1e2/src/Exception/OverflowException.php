<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class OverflowException extends \OverflowException implements Graph\Exception
{
}
