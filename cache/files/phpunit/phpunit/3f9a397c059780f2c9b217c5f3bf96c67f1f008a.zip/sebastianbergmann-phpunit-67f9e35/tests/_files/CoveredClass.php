<?php declare(strict_types=1);
/*
 * This file is part of PHPUnit.
 *
 * (c) Sebastian Bergmann <sebastian@phpunit.de>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
class CoveredParentClass
{
    public function publicMethod(): void
    {
        $this->protectedMethod();
    }

    protected function protectedMethod(): void
    {
        $this->privateMethod();
    }

    private function privateMethod(): void
    {
    }
}

class CoveredClass extends CoveredParentClass
{
    public function publicMethod(): void
    {
        parent::publicMethod();
        $this->protectedMethod();
    }

    protected function protectedMethod(): void
    {
        parent::protectedMethod();
        $this->privateMethod();
    }

    private function privateMethod(): void
    {
    }
}
