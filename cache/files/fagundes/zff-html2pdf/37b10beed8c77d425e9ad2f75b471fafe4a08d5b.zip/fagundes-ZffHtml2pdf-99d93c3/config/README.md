DO NOT EDIT THE CONFIG FILES DIRECTLY IN THIS DIRECTORY!
--------------------------------------------------------

Copy the dist file into your `./config/autoload` directory. Remove the .dist part.

Or you can copy it content into your `./module/MyExampleModule/config/module.config.php` file.