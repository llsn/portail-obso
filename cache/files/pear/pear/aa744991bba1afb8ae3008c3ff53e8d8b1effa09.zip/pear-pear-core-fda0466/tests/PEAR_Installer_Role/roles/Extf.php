<?php
class PEAR_Installer_Role_Extf extends PEAR_Installer_Role_Common{}
