<?php
class PEAR_Installer_Role_Scriptf extends PEAR_Installer_Role_Common{}
