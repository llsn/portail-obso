<?php
class PEAR_Installer_Role_Phpf extends PEAR_Installer_Role_Common{}
