<?php
class PEAR_Installer_Role_Dataf extends PEAR_Installer_Role_Common{}
